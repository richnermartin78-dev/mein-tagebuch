# Mein Tagebuch PWA v2.2

Private, installierbare Tagebuch-Web-App mit:
- lokaler Speicherung
- Supabase Auth (E-Mail + Passwort)
- Cloud-Synchronisierung zwischen Geräten
- Offline-Warteschlange
- Konfliktauflösung über Zeitstempel ("neuere Änderung gewinnt")
- Verlauf, Kalender, 7-/30-Tage-Auswertung
- JSON-Backup / Import
- CSV-Export
- Veröffentlichung über GitHub Pages

## Änderungen in v2.2

- Eine Hintergrund-Synchronisierung überschreibt keinen noch nicht gespeicherten Formulartext.
- Einträge, die während einer Synchronisierung gespeichert oder gelöscht werden, bleiben erhalten bzw. gelöscht und werden anschliessend synchronisiert.
- Weitere Offline-Löschungen werden nicht mehr versehentlich aus der Warteschlange entfernt.
- Beim erneuten Speichern eines gelöschten Datums wird dessen ausstehende Löschung aufgehoben.
- Ausstehende Änderungen sind am Cloud-Status erkennbar; ein Fehler bleibt bis zum nächsten Synchronisierungsversuch sichtbar.
- Der aktualisierte Service Worker lädt die neue App-Version und entfernt nur alte Tagebuch-Caches.

Bestehende Speicher-Schlüssel, das Backup-Format und die Supabase-Tabelle bleiben kompatibel. Für diese Aktualisierung ist keine neue SQL-Abfrage nötig.

### Bestehende Installation aktualisieren

Siehe `UPDATE_ANLEITUNG.txt`. Für die App selbst müssen nur `app.js` und `sw.js` ersetzt werden. Die bestehende Cloud-Konfiguration auf dem Gerät bleibt erhalten.

## 1. Lokal testen

`index.html` kann direkt geöffnet werden. Lokale Einträge funktionieren sofort.

Für PWA/Service Worker sollte die App über HTTPS oder einen lokalen Webserver laufen.

## 2. Supabase erstellen

1. Neues Supabase-Projekt anlegen.
2. Im **SQL Editor** den kompletten Inhalt von `supabase.sql` ausführen.
3. Unter **Settings -> API Keys** den **Publishable Key** kopieren.
4. Project URL und Publishable Key entweder:
   - in `config.js` eintragen, oder
   - später in der App unter **Einstellungen -> Cloud-Synchronisierung** einfügen.
5. Niemals Secret-/Service-Role-Key in die App eintragen.

## 3. Login

Unter **Einstellungen**:
- E-Mail + Passwort
- `Konto erstellen`
- falls Supabase E-Mail-Bestätigung verlangt: E-Mail bestätigen
- anmelden
- `Jetzt synchronisieren`

Für die E-Mail-Bestätigung sollte in Supabase Auth die Site URL auf die spätere GitHub-Pages-Adresse gesetzt werden.

## 4. GitHub Pages

Repository erstellen, diese Dateien hochladen und auf `main` committen.

Für eine neue Veröffentlichung in GitHub:
**Settings -> Pages -> Build and deployment -> Source: Deploy from a branch**

Branch: `main`, Ordner: `/ (root)`, anschliessend **Save**. In diesem ZIP ist kein GitHub-Actions-Workflow enthalten. Bei einer bereits laufenden Veröffentlichung die vorhandenen Pages-Einstellungen beibehalten.

Hinweis: Bei GitHub Free funktioniert Pages aus öffentlichen Repositories. Der Repository-Code enthält keine Tagebucheinträge. Ein Supabase Publishable Key ist für Browser-Apps gedacht; die eigentliche Zugriffskontrolle erfolgt über Auth + Row Level Security.

## 5. Synchronisierungsverhalten

- Speichern funktioniert immer lokal.
- Online + angemeldet: Synchronisierung startet automatisch.
- Offline: Änderungen werden lokal als "wartet" markiert.
- Sobald das Gerät wieder online ist, wird synchronisiert.
- Bei Änderungen desselben Datums auf zwei Geräten gewinnt die zeitlich neuere Änderung.
- Offline-Löschungen werden beim nächsten Sync an Supabase übertragen.

## Datenschutz-Hinweis

Diese Version nutzt Supabase Auth + Row Level Security, aber **keine Ende-zu-Ende-Verschlüsselung der Tagebuchtexte**. Die Daten werden nicht im GitHub-Repository gespeichert. Für eine zusätzliche E2E-Verschlüsselung kann eine spätere Version die Texte bereits im Browser verschlüsseln, bevor sie Supabase erreichen.

## Regressionstests

Mit Node.js, ohne zusätzliche Pakete:

```bash
node tests/sync.test.cjs
```

Die Tests führen den App-Code mit einem simulierten DOM und einer simulierten Cloud aus. Sie prüfen unter anderem lokale Speicherung, gleichzeitige Eingaben und Synchronisierung, Löschungen, Konflikte und Netzwerkfehler. Sie ersetzen keinen Test der Anmeldung und Synchronisierung mit dem tatsächlich konfigurierten Supabase-Projekt auf dem Gerät.
