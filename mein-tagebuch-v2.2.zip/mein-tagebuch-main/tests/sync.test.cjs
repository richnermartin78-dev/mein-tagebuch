const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');

const appDir = process.argv[2] || path.resolve(__dirname,'..');
function deferred() {
  let resolve;
  const promise = new Promise(r => { resolve = r; });
  return {promise, resolve};
}
function entry(date = '2026-10-21', text = 'Gespeicherter Text', modifiedAt = '2026-10-20T10:00:00.000Z', dirty = true) {
  return {date,mood:3,energy:5,tension:5,sleep:3,thoughts:text,good:'',hard:'',helped:'',moment:'',tomorrow:'',feelings:[],selfcare:[],modifiedAt,dirty};
}
function remote(e) {
  const {date,modifiedAt,dirty,...fields} = e;
  return {...fields,user_id:'test-user',entry_date:date,client_modified_at:modifiedAt};
}
async function setup(local = [], cloud = []) {
  const nodes = new Map();
  const makeNode = (id, value = '') => ({id,value,textContent:'',innerHTML:'',style:{},dataset:{},
    className:'',classList:{toggle(){},add(){},remove(){}},listeners:{},
    addEventListener(type,fn){this.listeners[type]=fn},
    getContext(){return new Proxy({}, {get:() => () => {}})}
  });
  const html=fs.readFileSync(path.join(appDir,'index.html'),'utf8');
  for (const match of html.matchAll(/<[^>]*\bid="([^"]+)"[^>]*>/g)) {
    const value=match[0].match(/\bvalue="([^"]*)"/)?.[1] || '';
    nodes.set(match[1],makeNode(match[1],value));
  }
  const values = new Map([['journal.entries.v2',JSON.stringify(local)]]);
  const storage = {getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,String(v)),removeItem:k=>values.delete(k)};
  const timers = new Map(); let timerId=0;
  const context = vm.createContext({
    document:{querySelector:s=>{
      if(s==='#authNotice .note') return nodes.get('authNotice');
      if(!s.startsWith('#') || !nodes.has(s.slice(1))) throw new Error('Unknown selector: '+s);
      return nodes.get(s.slice(1));
    },querySelectorAll:()=>[],title:''},
    localStorage:storage,navigator:{onLine:false},location:{origin:'http://localhost',pathname:'/',protocol:'http:'},
    console:{error(){},warn(){},log(){}},matchMedia:()=>({matches:false}),
    confirm:()=>true,alert:message=>{context.alerts.push(message)},alerts:[],
    setTimeout:(fn,ms)=>{const id=++timerId;timers.set(id,{fn,ms});return id},clearTimeout:id=>timers.delete(id),
    addEventListener(){},scrollTo(){},Date,Set,Map,JSON,Blob,URL,
  });
  context.window=context;
  vm.runInContext(fs.readFileSync(path.join(appDir,'app.js'),'utf8'),context);
  await Promise.resolve(); await Promise.resolve();
  const state = {rows:new Map(cloud.map(e=>[e.entry_date,structuredClone(e)])),calls:[],gate:null,fail:null};
  const client={from:()=>{
    const query={kind:'select',filters:{},select(){this.kind='select';return this},
      delete(){this.kind='delete';return this},eq(k,v){this.filters[k]=v;return this},order(){return this},
      upsert(payload){this.kind='upsert';this.payload=structuredClone(payload);return this},
      async then(resolve,reject){
        try{
          const kind=this.kind; state.calls.push({kind,date:this.payload?.entry_date||this.filters.entry_date});
          if(state.gate?.kind===kind){const gate=state.gate;state.gate=null;gate.started.resolve();await gate.release.promise}
          if(state.fail===kind){state.fail=null;return resolve({data:null,error:new Error('Simulierter Netzwerkfehler')})}
          if(kind==='upsert')state.rows.set(this.payload.entry_date,this.payload);
          if(kind==='delete')state.rows.delete(this.filters.entry_date);
          resolve({data:kind==='select'?[...state.rows.values()].map(x=>structuredClone(x)):null,error:null});
        }catch(error){reject(error)}
      }
    };return query;
  }};
  context.testClient=client;
  vm.runInContext("sb=testClient;currentUser={id:'test-user',email:'test@example.test'};navigator.onLine=true",context);
  return {
    context,nodes,state,storage,
    run:code=>vm.runInContext(code,context),
    entries:()=>JSON.parse(storage.getItem('journal.entries.v2')||'[]'),
    gate(kind){const gate={kind,started:deferred(),release:deferred()};state.gate=gate;return gate},
    async flush(){for(let i=0;i<20;i++){
      const scheduled=[...timers].filter(([,t])=>t.ms<1000);
      if(!scheduled.length)return;
      for(const [id,t] of scheduled){timers.delete(id);await t.fn()}
    }throw new Error('Unexpected sync retry loop')}
  };
}
const tests=[];
function test(name,fn){tests.push({name,fn})}
test('Lokales Speichern und erneutes Öffnen',async()=>{
  const s=await setup();s.context.navigator.onLine=false;
  s.nodes.get('entryDate').value='2026-10-21';s.nodes.get('thoughts').value='Mein Tag';
  s.run('saveEntry();clearForm();loadEntry("2026-10-21")');
  assert.equal(s.nodes.get('thoughts').value,'Mein Tag');assert.equal(s.entries()[0].dirty,true);
});
test('Neuer lokaler Eintrag wird in die Cloud übertragen',async()=>{
  const s=await setup([entry()]);await s.run('syncNow(false)');
  assert.equal(s.state.rows.get('2026-10-21').thoughts,'Gespeicherter Text');
  assert.equal(s.entries()[0].dirty,false);
});
test('Nicht gespeicherter Text bleibt bei Hintergrund-Sync erhalten',async()=>{
  const e=entry(undefined,'Gespeichert',undefined,false),s=await setup([e],[remote(e)]);
  s.nodes.get('thoughts').value='Gerade noch am Schreiben';await s.run('syncNow(false)');
  assert.equal(s.nodes.get('thoughts').value,'Gerade noch am Schreiben');
  assert.equal(s.entries()[0].thoughts,'Gespeichert');
});
test('Speichern während einer Cloud-Abfrage verliert keine Änderungen',async()=>{
  const e=entry(undefined,'Alt',undefined,false),s=await setup([e],[remote(e)]),gate=s.gate('select');
  const syncing=s.run('syncNow(false)');await gate.started.promise;
  s.nodes.get('thoughts').value='Während Sync geändert';s.run('saveEntry()');
  gate.release.resolve();await syncing;
  assert.equal(s.entries()[0].thoughts,'Während Sync geändert');
  await s.flush();assert.equal(s.state.rows.get(e.date).thoughts,'Während Sync geändert');
});
test('Neuer Eintrag während einer Cloud-Abfrage bleibt erhalten',async()=>{
  const s=await setup(),gate=s.gate('select'),syncing=s.run('syncNow(false)');await gate.started.promise;
  s.nodes.get('thoughts').value='Neuer Eintrag während Sync';s.run('saveEntry()');
  gate.release.resolve();await syncing;
  assert.equal(s.entries()[0]?.thoughts,'Neuer Eintrag während Sync');
  await s.flush();assert.equal(s.state.rows.size,1);
});
test('Änderung während eines Uploads bleibt erhalten und wird nachgesendet',async()=>{
  const s=await setup([entry()]),gate=s.gate('upsert'),syncing=s.run('syncNow(false)');await gate.started.promise;
  s.nodes.get('thoughts').value='Neuer als laufender Upload';s.run('saveEntry()');
  gate.release.resolve();await syncing;
  assert.equal(s.entries()[0].thoughts,'Neuer als laufender Upload');
  await s.flush();assert.equal(s.state.rows.get('2026-10-21').thoughts,'Neuer als laufender Upload');
});
test('Löschen während einer Cloud-Abfrage belebt den Eintrag nicht wieder',async()=>{
  const e=entry(undefined,'Zu löschen',undefined,false),s=await setup([e],[remote(e)]),gate=s.gate('select');
  const syncing=s.run('syncNow(false)');await gate.started.promise;s.run('deleteEntry("2026-10-21")');
  gate.release.resolve();await syncing;assert.equal(s.entries().length,0);
  await s.flush();assert.equal(s.state.rows.size,0);
});
test('Weitere Offline-Löschung während Sync bleibt in der Warteschlange',async()=>{
  const a=entry('2026-10-20'),b=entry('2026-10-21'),s=await setup([b],[remote(a),remote(b)]);
  s.storage.setItem('journal.deleted.v2',JSON.stringify([a.date]));
  const gate=s.gate('delete'),syncing=s.run('syncNow(false)');await gate.started.promise;
  s.run('deleteEntry("2026-10-21")');gate.release.resolve();await syncing;await s.flush();
  assert.equal(s.state.rows.size,0);assert.equal(s.entries().length,0);
});
test('Ein gelöschter und neu gespeicherter Tag wird wieder synchronisiert',async()=>{
  const s=await setup();s.context.navigator.onLine=false;
  s.storage.setItem('journal.deleted.v2',JSON.stringify(['2026-10-21']));
  s.nodes.get('thoughts').value='Neu erstellt';s.run('saveEntry()');
  assert.deepEqual(JSON.parse(s.storage.getItem('journal.deleted.v2')),[]);
  s.context.navigator.onLine=true;await s.run('syncNow(false)');assert.equal(s.state.rows.size,1);
});
test('Neuere Cloud-Version gewinnt einen normalen Konflikt',async()=>{
  const e=entry(),r=remote(entry(undefined,'Neuer auf zweitem Gerät','2026-10-21T11:00:00.000Z'));
  const s=await setup([e],[r]);await s.run('syncNow(false)');
  assert.equal(s.entries()[0].thoughts,r.thoughts);assert.equal(s.entries()[0].dirty,false);
});
test('Auf anderem Gerät gelöschter synchronisierter Eintrag verschwindet lokal',async()=>{
  const s=await setup([entry(undefined,undefined,undefined,false)]);await s.run('syncNow(false)');
  assert.equal(s.entries().length,0);
});
test('Netzwerkfehler lässt lokale Änderungen erneut synchronisierbar',async()=>{
  const s=await setup([entry()]);s.state.fail='upsert';await s.run('syncNow(false)');
  assert.equal(s.entries()[0].dirty,true);assert.equal(s.nodes.get('thoughts').value,'Gespeicherter Text');
  await s.run('syncNow(false)');assert.equal(s.entries()[0].dirty,false);
});
test('Abmelden während einer Cloud-Abfrage übernimmt keine verspäteten Daten',async()=>{
  const r=remote(entry(undefined,'Cloud-Inhalt')),s=await setup([],[r]),gate=s.gate('select');
  const syncing=s.run('syncNow(false)');await gate.started.promise;s.run('currentUser=null');
  gate.release.resolve();await syncing;assert.equal(s.entries().length,0);
});
test('Service Worker lädt die App-Dateien beim Update frisch',async()=>{
  const handlers={},requests=[];
  const context=vm.createContext({URL,Request,
    self:{location:{href:'https://example.test/mein-tagebuch/sw.js'},addEventListener:(name,fn)=>handlers[name]=fn,skipWaiting:async()=>{}},
    caches:{open:async()=>({addAll:async values=>requests.push(...values)})}
  });
  vm.runInContext(fs.readFileSync(path.join(appDir,'sw.js'),'utf8'),context);
  let completion;handlers.install({waitUntil:promise=>{completion=promise}});await completion;
  assert.equal(requests.length,8);assert.ok(requests.every(request=>request.cache==='reload'));
  assert.ok(requests.some(request=>request.url==='https://example.test/mein-tagebuch/app.js'));
});
test('Service Worker erhält Caches anderer Apps auf derselben Domain',async()=>{
  const handlers={},deleted=[];
  const context=vm.createContext({URL,Request,
    self:{location:{href:'https://example.test/mein-tagebuch/sw.js'},addEventListener:(name,fn)=>handlers[name]=fn,clients:{claim:async()=>{}}},
    caches:{keys:async()=>['mein-tagebuch-v2.1','mein-tagebuch-v2.2','andere-app-v1'],delete:async key=>deleted.push(key)}
  });
  vm.runInContext(fs.readFileSync(path.join(appDir,'sw.js'),'utf8'),context);
  let completion;handlers.activate({waitUntil:promise=>{completion=promise}});await completion;
  assert.deepEqual(deleted,['mein-tagebuch-v2.1']);
});

(async()=>{
  let failed=0;
  for(const {name,fn} of tests){try{await fn();console.log('PASS '+name)}catch(error){failed++;console.log('FAIL '+name+'\n  '+error.message)}}
  console.log(`${tests.length-failed}/${tests.length} bestanden`);process.exitCode=failed?1:0;
})();
